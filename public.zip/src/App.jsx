import React from 'react'
import Usememo from './components/Usememo'
import WithUseMemo from './components/Withusememo'
import WithoutUseMemo from './components/Withoutusememo'
import Portfolio from './components/Portfolio.jsx/Portfolio'
import Display from './components/customhook/Display'

const App = () => {
  return (
    <div>
      <Usememo />
      <WithUseMemo />
      <WithoutUseMemo />
      <Portfolio />
      <Display />
    </div>
  )
}

export default App