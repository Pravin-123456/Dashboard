import React, { useCallback, useMemo, useState } from "react";
import ProjectCard from "./ProjectCard"; // Make sure this is memoized

const mockProjects = [
  { id: 1, title: "E-commerce App", description: "React + Node.js" },
  { id: 2, title: "Portfolio Website", description: "React + Tailwind" },
  { id: 3, title: "Blog Platform", description: "MERN Stack" },
];

const Portfolio = () => {
  const [selectedProject, setSelectedProject] = useState(null);
  const [theme, setTheme] = useState("light");

  // ✅ Stable callback passed to ProjectCard
  const handleProjectClick = useCallback((project) => {
    setSelectedProject(project);
    console.log("Opening project:", project.title);
  }, []);

  // ✅ Optionally filter or modify project list using useMemo
  const filteredProjects = useMemo(() => {
    // For demo, just return all; in real world, apply filters/search here
    return mockProjects;
  }, []);

  // ✅ Memoize the JSX list so it's not regenerated on unrelated renders
  const projectList = useMemo(() => {
    return filteredProjects.map((proj) => (
      <ProjectCard key={proj.id} project={proj} onClick={handleProjectClick} />
    ));
  }, [filteredProjects, handleProjectClick]);

  // ✅ Optional theme style memoization (for inline styling)
  const themeStyles = useMemo(() => ({
    backgroundColor: theme === "light" ? "#fff" : "#1a202c",
    color: theme === "light" ? "#000" : "#fff",
  }), [theme]);

  return (
    <div style={themeStyles} className="p-4 min-h-screen transition-colors duration-300">
      <h2 className="text-2xl font-bold mb-4">My Projects</h2>

      <div className="grid gap-4 md:grid-cols-3">
        {projectList}
      </div>

      <button
        className="mt-6 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        onClick={() => setTheme((prev) => (prev === "light" ? "dark" : "light"))}
      >
        Toggle Theme
      </button>

      {selectedProject && (
        <div className="mt-6 p-4 border rounded bg-gray-100 text-black">
          <h3 className="text-xl font-semibold">{selectedProject.title}</h3>
          <p className="text-sm">{selectedProject.description}</p>
        </div>
      )}
    </div>
  );
};

export default Portfolio;
