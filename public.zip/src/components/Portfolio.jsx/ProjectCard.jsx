import React from "react";

const ProjectCard = React.memo(({ project, onClick }) => {
  console.log("Rendering:", project.title);
  return (
    <div
      onClick={() => onClick(project)}
      className="border p-4 rounded cursor-pointer hover:bg-gray-100"
    >
      <h3 className="text-lg font-semibold">{project.title}</h3>
      <p className="text-sm text-gray-500">{project.description}</p>
    </div>
  );
});

export default ProjectCard;
