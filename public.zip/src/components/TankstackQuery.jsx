import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import React, { useMemo } from "react";

// Memoized image item
const ImageItem = React.memo(({ url, id }) => {
  return <img key={id} src={url} alt="image" width={500} fetchPriority="high" />;
});

// Fetch function
const fetchData = async () => {
  const response = await axios.get("http://localhost:3001/images");
  return response.data;
};

const TankstackQuery = () => {
  const { data = [], isLoading, error } = useQuery({
    queryKey: ["images"],
    queryFn: fetchData,
    staleTime: 5000,
    refetchInterval: 1000,
    refetchIntervalInBackground: true,
  });

  const renderedImages = useMemo(() => {
    return data.map((img) => (
      <ImageItem key={img.id} id={img.id} url={img.url} />
    ));
  }, [data]);

  if (isLoading) return <p>loading...</p>;
  if (error) return <p>error loading...</p>;

  console.log(data.length);
  
  return <div><ul>{renderedImages}</ul></div>;
};

export default TankstackQuery;
