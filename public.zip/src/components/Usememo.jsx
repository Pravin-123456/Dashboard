import React, { useState, useMemo } from "react";

const Usememo = () => {
  const [dark, setDark] = useState(false);

  const theme = useMemo(() => ({
    background: dark ? "bg-black" : "bg-white",
    color: dark ? "text-white" : "text-black",
  }), [dark]);

  return (
    <div className={`w-full h-screen ${theme.background} ${theme.color} flex flex-col items-center justify-center`}>
      <h2 className="text-2xl mb-4">{dark ? "Dark Theme" : "Light Theme"}</h2>
      <button
        onClick={() => setDark(prev => !prev)}
        className="px-4 py-2 rounded bg-gray-300 hover:bg-gray-400 text-black"
      >
        {dark ? "Change to Light" : "Change to Dark"}
      </button>
    </div>
  );
};

export default Usememo;
