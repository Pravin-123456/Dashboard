import React, { useState } from "react";

// Very slow recursive Fibonacci function
const fibonacci = (n) => {
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
};

const WithoutUseMemo = () => {
  const [count, setCount] = useState(0);
  const [num, setNum] = useState(30); // expensive computation

  const fib = () => {
  console.time("WithoutUseMemo");
  fibonacci(num);
  console.timeEnd("WithoutUseMemo");
};


  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-2">Without useMemo</h2>
      <p>
        Fibonacci of {num}: {fib}
      </p>
      <button
        onClick={() => setCount(count + 1)}
        className="mt-2 px-4 py-2 bg-blue-500 text-white rounded"
      >
        Re-render (Count: {count})
      </button>
    </div>
  );
};

export default WithoutUseMemo;
