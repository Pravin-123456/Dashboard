import React from "react";
import { useHook } from "./Hook";

const Display = () => {
  const { data, isLoading, isError } = useHook("Post", "/posts");

  if (isLoading) {
    return <h1>loading...</h1>;
  }
  if (isError) {
    return <h1>error in fetching</h1>;
  }

  console.log(data);
  

  return (
    <div>
      {data?.map((post, index) => (
        <ul key={index}>
          <p>{post.title}</p>
          <p>{post.body}</p>
        </ul>
      ))}
    </div>
  );
};

export default Display;
