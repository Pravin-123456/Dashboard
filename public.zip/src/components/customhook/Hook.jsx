import { useCallback } from "react";
import { Axios } from "./Axios"
import { useQuery } from "@tanstack/react-query";

const fetch = async (url) => {
    const response = await Axios.get(url);
    return response.data;
}

export const useHook = ( key, url ) => {
  const fetchdata = useCallback(() => fetch(url),[url]);

  const query = useQuery({
    queryKey: [key],
    queryFn: fetchdata,
    staleTime: 1000 * 60 * 5,
    refetchOnWindowFocus: false
  });
  return {
    ...query
  };
};

