import React, { useState, useMemo } from "react";

const fibonacci = (n) => {
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
};

const WithUseMemo = () => {
  const [count, setCount] = useState(0);
  const [num, setNum] = useState(30);

  const fib = useMemo(() => {
    console.time("WithUseMemo started")
    fibonacci(num), [num];
    console.timeEnd("WithUseMemo ended")
  }); // ✅ memoized

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-2">With useMemo</h2>
      <p>
        Fibonacci of {num}: {fib}
      </p>
      <button
        onClick={() => setCount(count + 1)}
        className="mt-2 px-4 py-2 bg-green-500 text-white rounded"
      >
        Re-render (Count: {count})
      </button>
    </div>
  );
};

export default WithUseMemo;
