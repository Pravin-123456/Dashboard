import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination } from "swiper/modules";
import No_image from "../../assets/no-image.png";
import { ChevronLeft, ChevronRight } from "lucide-react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";

const Slider = ({ loading, Projects }) => {
  const base_url = "http://192.168.90.43:5001";
  const imageExtensions = [
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
    ".svg",
    ".gif",
    ".avif",
  ];

  const isValidImage = (filename) => {
    if (!filename) return false;
    const lower = filename.toLowerCase();
    return imageExtensions.some((ext) => lower.endsWith(ext));
  };

  return (
    <div className="w-full border-1 border-white rounded-2xl relative overflow-hidden justify-self-start h-[82vh] shadow-xl">
      {loading ? (
        <p className="text-center text-lg font-semibold text-gray-600 h-[80vh]">
          Loading projects...
        </p>
      ) : Projects?.length > 0 ? (
        <>
          <div className="custom-prev absolute top-1/2 left-4 z-10 cursor-pointer bg-white p-2 rounded-full shadow-md -translate-y-1/2">
            <ChevronLeft size={"2vw"} />
          </div>
          <div className="custom-next absolute top-1/2 right-4 z-10 cursor-pointer bg-white p-2 rounded-full shadow-md -translate-y-1/2">
            <ChevronRight size={"2vw"} />
          </div>

          <Swiper
            modules={[Navigation, Pagination]}
            navigation={{
              prevEl: ".custom-prev",
              nextEl: ".custom-next",
            }}
            loop={true}
            spaceBetween={30}
            slidesPerView={1} 
            className="rounded-xl shadow-lg"
          >
            {Projects.map((project, index) => (
              <SwiperSlide key={index}>
                <div className="relative w-full h-[82vh] bg-white">
                  <img
                    src={
                      project.image && isValidImage(project.image)
                        ? `${base_url}${project.image}`
                        : No_image
                    }
                    alt={project.title || `Slide ${index + 1}`}
                    className="w-full h-full object-cover rounded-xl hover:cursor-pointer"
                    onClick={() =>
                      project.link && window.open(project.link, "_blank")
                    }
                    loading="lazy"
                  />
                  {project.title && (
                    <div className="absolute bottom-0 left-0 w-full bg-[#fff] bg-opacity-50 text-[#983BFA] p-4 rounded-b-xl">
                      <h2 className="text-[1.2vw] font-semibold text-center">
                        {project.title}
                      </h2>
                    </div>
                  )}
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </>
      ) : (
        <p className="text-center text-gray-500">No projects available.</p>
      )}
    </div>
  );
};

export default Slider;
