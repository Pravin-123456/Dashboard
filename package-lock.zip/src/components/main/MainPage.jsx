import { Suspense, lazy } from "react";
import { Outlet } from "react-router-dom";
import SidebarL from "../sidebar/SidebarL";
import CreateUserModel from "../Modals/CreateUpdateUserModel";

const SidebarR = lazy(() => import("../sidebar/SidebarR"));

const MainPage = () => {

  return (
    <main className="grid grid-cols-[1fr_4fr_1.5fr] bg-[#F1F1FB]">
      <SidebarL />
      <div className="relative bg-[#F1F1FB] overflow-hidden">
        <Suspense fallback={<div className="text-center p-4">Loading...</div>}>
          <Outlet />
        </Suspense>
      </div>
      <SidebarR />
      <CreateUserModel />
    </main>
  );
};

export default MainPage;
