import { lazy, Suspense, useEffect, useRef, useState } from "react";
// import { Table } from "antd";
// import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
import { PencilLine, Search, Trash } from "lucide-react";
import { toast } from "react-toastify";
import { DeleteProjectDetails, GetProjectDetails } from "../../api/projects";
import CreateUpdateProjectModal from "../Modals/CreateUpdateProjectModal";
import DeleteProjectModal from "../Modals/DeletePorjectModal";
import { SearchProjects } from "../../api/search";

const Table = lazy(() => import("antd/es/table"));
const Pagination = lazy(() => import("@mui/material/Pagination"));

const PAGE_SIZE = 10;

const Projects = () => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedProjects, setSelectedProjects] = useState(null);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const path = "http://192.168.90.43:5001";
  const inputRef = useRef(null);

  const totalPages = Math.ceil(projects?.length / PAGE_SIZE);
  const offset = (currentPage - 1) * PAGE_SIZE;
  const currentData = projects?.slice(offset, offset + PAGE_SIZE);
  const [search, setSearch] = useState("");
  const [Preview, setPreview] = useState(null);

  // const fetchProjects = async () => {
  //   setLoading(true);
  //   try {
  //     const response = await GetProjectDetails();
  //     // const data = response.filter(search)
  //     setProjects(response);
  //   } catch (error) {
  //     console.log("fetch getusers error", error.message);
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  const fetchProjects = async (search) => {
    try {
      setLoading(true);

      const response = search
        ? await SearchProjects(search.trim())
        : await GetProjectDetails();

      const sortedUsers = response?.sort((a, b) => b.project_id - a.project_id);
      console.log("Projects from dashboard", search);
      setProjects(sortedUsers || []);
    } catch (error) {
      console.log("Fetch Projects Error", error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects(search);
  }, [search]);

  const handleEdit = (project_id) => {
    const user = projects?.find((p) => p.project_id === project_id);
    setSelectedProjects(user);
    setIsModalVisible(true);
  };

  const handleDelete = (project_id, title) => {
    setSelectedProjects({ project_id, title });
    setIsDeleteModalOpen(true);
  };

  const handlePageChange = (event, value) => {
    setCurrentPage(value);
  };

  const handleOk = async () => {
    setSelectedProjects(null);
    setPreview(null);
    await fetchProjects();
    setIsModalVisible(false);
    setIsDeleteModalOpen(false);
  };

  const handleCancel = () => {
    setSelectedProjects(null);
    setPreview(null);
    setIsModalVisible(false);
    setIsDeleteModalOpen(false);
  };

  const handleConfirmDelete = async (project_id, title) => {
    try {
      await DeleteProjectDetails(project_id);
      setIsDeleteModalOpen(false);
      toast.success(`${title} deleted successfully`);
      console.log("testing delete con fun", project_id, title);
      setSelectedProjects(null);
    } catch (error) {
      console.log(error);
      toast.error("Failed to delete user.");
    } finally {
      await fetchProjects();
    }
  };

  const hideDeleteModal = () => {
    setIsDeleteModalOpen(false);
  };

  const columns = [
    {
      title: "Sl No",
      dataIndex: "No",
      key: "No",
      width: "10%",
      align: "center",
      render: (text, record, index) => {
        const calculatedIndex = (currentPage - 1) * PAGE_SIZE + (index + 1);
        return calculatedIndex;
      },
    },
    {
      title: "Image",
      dataIndex: "image",
      key: "image",
      width: "15%",
      align: "center",
      render: (image) => (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <img
            src={`${path}${image}`}
            alt="example"
            loading="lazy"
            style={{
              width: "2vw",
              height: "2vw",
              objectFit: "cover",
              borderRadius: "6px",
            }}
            onClick={() => {
              setImage(`${path}${image}`);
              setIsOpen(true);
            }}
          />
        </div>
      ),
    },
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
      width: "27%",
      render: (title) => (
        <p className="text-wrap">
          {title.length > 25 ? `${title.slice(0, 25)}...` : title}
        </p>
      ),
    },
    {
      title: "Link",
      dataIndex: "link",
      key: "link",
      width: "50%",
      render: (link) => (
        <p className="text-wrap">
          <a href={link} target="_blank" rel="noopener noreferrer">
            {link.length > 50 ? `${link.slice(0, 50)}...` : link}
          </a>
        </p>
      ),
    },
    {
      title: "Actions",
      key: "actions",
      width: "15%",
      align: "center",
      render: (_, project) => (
        <div className="flex justify-center gap-4 pr-[.5vw]">
          <button onClick={() => handleEdit(project.project_id)} title="Edit">
            <PencilLine className="text-[#983BFA] cursor-pointer w-[1vw] hover:scale-110 transition" />
          </button>
          <button
            onClick={() => handleDelete(project.project_id, project.title)}
            title="Delete"
          >
            <Trash className="text-red-600 cursor-pointer w-[1vw] hover:scale-110 transition" />
          </button>
        </div>
      ),
    },
  ];

  // console.log("testing selected projects",selectedProjects);

  return (
    <div className="h-full">
      <div className=" mx-[1vw]  grid grid-rows-[10%_90%] items-between mt-[2vw]">
        <div className="flex justify-between">
          <div className="relative w-[15vw] text-right ">
            <div className="inline-block w-full relative bg-white rounded-2xl shadow-xl">
              <Search
                size={20}
                className="w-[.9vw] h-[2vh] absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500"
              />
              <input
                ref={inputRef}
                type="text"
                placeholder="Search..."
                onBlur={() => setShowInput(false)}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 rounded-[.7vw] px-2 py-[0.4vw] text-[0.9vw] w-full transition duration-300 outline-none"
              />
            </div>
          </div>
          <div className="">
            <button
              className="bg-[#973bfab6] rounded-[.5vw] cursor-pointer px-[.5vw] py-[.3vw] text-[1vw] hover:bg-[#983BFA] transition shadow-xl text-white "
              onClick={() => {
                setIsModalVisible(true);
              }}
            >
              Add Project
            </button>
          </div>
        </div>

        <div className="h-[80vh]">
          <Suspense fallback={<h1>loading..</h1>}>
            <Table
              pagination={false}
              loading={loading}
              columns={columns}
              dataSource={currentData ? currentData : null}
              rowKey="No"
              className="projects-table shadow-xl"
            />
          </Suspense>

          {projects.length > 10 ? (
            <div className="flex justify-end mt-[1vw]">
              <Stack spacing={2}>
                <Pagination
                  count={totalPages}
                  page={currentPage}
                  onChange={handlePageChange}
                  className="custom-pagination"
                  variant="outlined"
                  shape="rounded"
                  color="primary"
                />
              </Stack>
            </div>
          ) : (
            ""
          )}
        </div>
      </div>
      <CreateUpdateProjectModal
        isModalVisible={isModalVisible}
        handleCancel={handleCancel}
        handleOk={handleOk}
        setIsModalVisible={setIsModalVisible}
        selectedProjects={selectedProjects}
        Projects={projects}
        setPreview={setPreview}
        Preview={Preview}
        className={"custom-modal"}
      />

      <DeleteProjectModal
        isDeleteModalOpen={isDeleteModalOpen}
        handleCancel={handleCancel}
        hideDeleteModal={hideDeleteModal}
        handleConfirmDelete={handleConfirmDelete}
        project_id={selectedProjects?.project_id}
        title={selectedProjects?.title}
      />
    </div>
  );
};

export default Projects;
