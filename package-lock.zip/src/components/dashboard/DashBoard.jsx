import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { GetProjectDetails } from "../../api/projects";
import { ListMinus, Search } from "lucide-react";
import { Grid2x2Plus } from "lucide-react";

import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";

const Slider = lazy(() => import("../slider/Slider"));
const List = lazy(() => import("../list/List"));

const DashBoard = () => {
  const [Projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isActive, setIsActive] = useState(true);
  const [search, setSearch] = useState("");
  const inputRef = useRef(null);

  // const fetchProjects = async (search) => {
  //   try {
  //     setLoading(true);

  //     const response = search
  //       ? await SearchProjects(search)
  //       : await GetProjectDetails();

  //     console.log("Projects from dashboard", search);
  //     setProjects(response || []);
  //   } catch (error) {
  //     console.log("Fetch Projects Error", error.message);
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  // const fetchProjects = async (search) => {
  //   try {
  //     setLoading(true);
  //     let response = [];
  //     if (search) {
  //       const data = await GetProjectDetails();
  //       const searchdata = data.filter((project) => project.title === search);
  //       response = searchdata;
  //     } else {
  //       const data = await GetProjectDetails();
  //       response = data
  //     }
  //     //  const response = search
  //     //   ? await SearchProjects(search)
  //     //   : await GetProjectDetails();
  //     // const response = await GetProjectDetails();
  //     console.log("Projects from dashboard:", response);
  //     setProjects(response || []);
  //   } catch (error) {
  //     console.log("Fetch Projects Error:", error.message);
  //     setProjects([]);
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  const fetchProjects = async (search) => {
    try {
      setLoading(true);

      const data = await GetProjectDetails();
      let filteredProjects = data;

      if (search) {
        filteredProjects = data.filter((project) =>
          project.title?.toLowerCase().includes(search.toLowerCase())
        );
      }
      const sortedUsers = filteredProjects?.sort((a, b) => b.project_id - a.project_id);

      console.log("Projects from dashboard:", filteredProjects);
      
      setProjects(sortedUsers || []);
    } catch (error) {
      console.log("Fetch Projects Error:", error.message);
      setProjects([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects(search);
  }, [search]);

  return (
    <div className="grid grid-rows-[9%_91%] mx-[1vw] mt-[2vw] h-full">
      <div className="flex justify-between">
        <div className="relative">
          <div className="relative w-[20vw] text-right ">
            <div className="inline-block w-full relative bg-white rounded-2xl shadow-xl">
              <Search
                size={20}
                className="w-[1vw] h-[2vh] absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500"
              />
              <input
                ref={inputRef}
                type="text"
                placeholder="Search..."
                // onBlur={() => setShowInput(false)}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 rounded-[.7vw] px-2 py-[0.4vw] text-[0.9vw] w-full transition duration-300 outline-none"
              />
            </div>
          </div>
        </div>
        <div className="flex rounded-[.5vw] bg-white shadow-xl h-[2vw]">
          {/* Grid Button */}
          <button
            onClick={() => setIsActive(true)}
            className="cursor-pointer rounded-[.5vw] transition-all duration-300 ease-in-out py-[.1vw] px-[.3vw]"
            style={{
              backgroundColor: isActive ? "#973bfab6" : "transparent",
              color: !isActive ? "black" : "white",
            }}
          >
            <span className="flex justify-between items-center">
              <Grid2x2Plus className="transition-transform duration-300 h-[1.5vw]" />
              <p className="pl-[.3vw] text-[.9vw]">Grid View </p>
            </span>
          </button>

          {/* List Button */}
          <button
            onClick={() => setIsActive(false)}
            className="cursor-pointer rounded-[.5vw] transition-all duration-300 ease-in-out py-[.1vw] px-[.3vw]"
            style={{
              backgroundColor: !isActive ? "#973bfab6" : "transparent",
              color: isActive ? "black" : "white",
            }}
          >
            <span className="flex justify-between items-center">
              <ListMinus className="transition-transform duration-300  h-[1.5vw]" />
              <p className="pl-[.3vw] text-[.9vw]">List View</p>
            </span>
          </button>
        </div>
      </div>
      <Suspense fallback={<h1>loading...</h1>}>
        {isActive ? (
          <Slider Projects={Projects} loading={loading} />
        ) : (
          <List Projects={Projects} loading={loading}/>
        )}
      </Suspense>
    </div>
  );
};

export default DashBoard;
