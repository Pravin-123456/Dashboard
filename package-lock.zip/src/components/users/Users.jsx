import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { GetUsers } from "../../api/users";

// import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
import { PencilLine, Search, Trash } from "lucide-react";
import { toast } from "react-toastify";
import CreateUpdateUserModel from "../Modals/CreateUpdateUserModel";
import DeleteUserModel from "../Modals/DeleteUserModel";
import { DeleteProjetUser } from "../../api/users";
import { Eye, EyeOff } from "lucide-react";
import { SearchUser } from "../../api/search";

const PAGE_SIZE = 10;

const Table = lazy(() => import("antd/es/table"));
const Pagination = lazy(() => import("@mui/material/Pagination"));

const Users = () => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const inputRef = useRef(null);
  const [visiblePasswords, setVisiblePasswords] = useState({});
  const [search, setsearch] = useState("");

  const totalPages = Math.ceil(users?.length / PAGE_SIZE);
  const offset = (currentPage - 1) * PAGE_SIZE;
  const currentData = users?.slice(offset, offset + PAGE_SIZE);

  const fetchUsers = async (search) => {
    setLoading(true);
    try {
      const response = await (search ? SearchUser(search.trim()) : GetUsers());

      const sortedUsers = response?.sort((a, b) => b.emp_no - a.emp_no);
      const normalizeUsers = sortedUsers?.map((user, index) => ({
        No: index + 1,
        emp_no: user.emp_no,
        user_name: user.user_name,
        pass: user.password,
        user_type: user.user_type,
        user_id: user.user_id,
      }));
      setUsers(normalizeUsers);
    } catch (error) {
      console.log("fetch getusers error", error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers(search);
  }, [search]);

  const handleEdit = (user_id) => {
    const user = users?.find((u) => u.user_id === user_id);
    setSelectedUser(user);
    setIsModalVisible(true);
  };

  const handleDelete = (user_id, user_name) => {
    setSelectedUser({ user_id, user_name });
    setIsDeleteModalOpen(true);
  };

  const handlePageChange = (event, value) => {
    setCurrentPage(value);
  };

  const handleOk = async () => {
    await fetchUsers();
    setSelectedUser(null);
    setIsModalVisible(false);
    setIsDeleteModalOpen(false);
  };

  const handleCancel = () => {
    setSelectedUser(null);
    setIsModalVisible(false);
    setIsDeleteModalOpen(false);
  };

  const handleConfirmDelete = async (user_id, user_name) => {
    try {
      await DeleteProjetUser(user_id);
      setIsDeleteModalOpen(false);
      toast.success(`${user_name} deleted successfully`);
      setSelectedUser(null);
    } catch (error) {
      console.log(error);
      toast.error("Failed to delete user.");
    } finally {
      await fetchUsers();
    }
  };

  const hideDeleteModal = () => {
    setIsDeleteModalOpen(false);
  };

  const columns = [
    {
      title: "Sl No",
      dataIndex: "No",
      key: "No",
      width: "7%",
      align: "center",
    },
    {
      title: "Employee ID",
      dataIndex: "emp_no",
      key: "emp_no",
      width: "15%",
    },
    {
      title: "Employee Name",
      dataIndex: "user_name",
      key: "user_name",
      width: "20%",
    },
    {
      title: "Password",
      dataIndex: "pass",
      key: "pass",
      width: "25%",
      render: (pass, record) => {
        const key = record.user_id || record.project_id;
        const isVisible = visiblePasswords[key];

        const toggleVisibility = () => {
          setVisiblePasswords((prev) => ({
            ...prev,
            [key]: !prev[key],
          }));
        };

        return (
          <div className="flex justify-between gap-2 mx-[4vw]">
            <span>{isVisible ? pass : "*".repeat(pass?.length || 8)}</span>
            <button onClick={toggleVisibility}>
              {isVisible ? (
                <Eye size="1vw" className="text-gray-600" />
              ) : (
                <EyeOff size="1vw" className="text-gray-600" />
              )}
            </button>
          </div>
        );
      },
    },

    {
      title: "Employee Type",
      dataIndex: "user_type",
      key: "user_type",
      width: "15%",
    },
    {
      title: "Actions",
      key: "actions",
      width: "10%",
      align: "center",
      render: (_, user) => (
        <div className="flex justify-center gap-4">
          <button onClick={() => handleEdit(user.user_id)} title="Edit">
            <PencilLine className="text-[#983BFA] cursor-pointer w-[1vw] hover:scale-110 transition" />
          </button>
          <button
            onClick={() => handleDelete(user.user_id, user.user_name)}
            title="Delete"
          >
            <Trash className="text-red-600 cursor-pointer w-[1vw] hover:scale-110 transition" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="h-full  mx-[1vw] mt-[2vw]">
      <div className="grid grid-rows-[10%_90%]">
        <div className="flex justify-between">
          <div className="relative w-[15vw] text-right ">
            <div className="inline-block w-full relative bg-white rounded-2xl shadow-xl">
              <Search
                size={20}
                className="w-[.9vw] h-[2vh] absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500"
              />
              <input
                ref={inputRef}
                type="text"
                placeholder="Search..."
                onBlur={() => setShowInput(false)}
                onChange={(e) => setsearch(e.target.value)}
                className="pl-10 rounded-[.7vw] px-2 py-[0.4vw] text-[0.9vw] w-full transition duration-300 outline-none"
              />
            </div>
          </div>
          <div className="">
            <button
              className="bg-[#973bfab6] rounded-[.5vw] cursor-pointer px-[.5vw] py-[.3vw] text-[1vw] hover:bg-[#983BFA] transition text-white shadow-xl "
              onClick={() => {
                setIsModalVisible(true);
              }}
            >
              Add user
            </button>
          </div>
        </div>
        <Suspense fallback={<h1>loading...</h1>}>
          <div className="w-full h-[80vh] relative">
            <Table
              pagination={false}
              loading={loading}
              columns={columns}
              dataSource={currentData ? currentData : null}
              rowKey="user_id"
              className="table w-full shadow-xl"
            />

            {users.length > 10 ? (
              <div className="flex justify-end mt-[1vw]">
                <Stack spacing={2}>
                  <Pagination
                    count={totalPages}
                    page={currentPage}
                    onChange={handlePageChange}
                    className="custom-pagination"
                    variant="outlined"
                    shape="rounded"
                    color="primary"
                  />
                </Stack>
              </div>
            ) : (
              ""
            )}
          </div>
        </Suspense>
      </div>
      <CreateUpdateUserModel
        isModalVisible={isModalVisible}
        handleCancel={handleCancel}
        handleOk={handleOk}
        selectedUser={selectedUser}
        users={users}
        className={"custom-modal"}
      />

      <DeleteUserModel
        isDeleteModalOpen={isDeleteModalOpen}
        handleCancel={handleCancel}
        hideDeleteModal={hideDeleteModal}
        handleConfirmDelete={handleConfirmDelete}
        user_id={selectedUser?.user_id}
        user_name={selectedUser?.user_name}
      />
    </div>
  );
};

export default Users;
