import React, { useEffect, useState } from "react";
import { Table } from "antd";
import Stack from "@mui/material/Stack";
import Pagination from "@mui/material/Pagination";
import DashboardImageModal from "../Modals/DashboardImageModal";

const List = ({ Projects, loading }) => {
  // const [loading, setLoading] = useState(true);
  const [projects, setProjects] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [IsOpen, setIsOpen] = useState(false);
  const [Image, setImage] = useState(null);

  const path = "http://192.168.90.43:5001";
  const PAGE_SIZE = 10;

  const totalPages = Math.ceil(projects.length / PAGE_SIZE);
  const offset = (currentPage - 1) * PAGE_SIZE;
  const currentData = projects.slice(offset, offset + PAGE_SIZE);

  const handlePageChange = (event, value) => {
    setCurrentPage(value);
  };

  const fetchProjects = async () => {
    try {
      const normalizedProjects = Projects.map((project, index) => ({
        index: index + 1,
        image: project.image,
        title: project.title,
        link: project.link,
      }));
      setProjects(normalizedProjects);
    } catch (error) {
      console.error("Error from list", error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, [Projects]);

  const columns = [
    {
      title: "Sl No",
      dataIndex: "index",
      key: "index",
      align: "center",
      width: "8%",
    },
    {
      title: "Image",
      dataIndex: "image",
      key: "image",
      align: "center",
      width: "15%",
      render: (image) => (
        <div className="flex justify-center items-center">
          <img
            src={`${path}${image}`}
            alt="example"
            loading="lazy"
            className="w-[2vw] h-[2vw] object-cover rounded cursor-pointer"
            onClick={() => {
              setImage(`${path}${image}`);
              setIsOpen(true);
            }}
          />
        </div>
      ),
    },
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
      width: "27%",
      render: (title) => (
        <p className="text-wrap">
          {title.length > 25 ? `${title.slice(0, 25)}...` : title}
        </p>
      ),
    },
    {
      title: "Link",
      dataIndex: "link",
      key: "link",
      width: "50%",
      render: (link) => (
        <p className="text-wrap">
          <a href={link} target="_blank" rel="noopener noreferrer">
            {link.length > 50 ? `${link.slice(0, 50)}...` : link}
          </a>
        </p>
      ),
    },
  ];

  return (
    <>
      <Table
        pagination={false}
        loading={loading}
        columns={columns}
        dataSource={currentData}
        rowKey="index"
        className="list-table"
      />

      {projects.length > 10 ? (
        <div className="flex justify-end mt-[1vw]">
          <Stack spacing={2}>
            <Pagination
              count={totalPages}
              page={currentPage}
              onChange={handlePageChange}
              className="custom-pagination"
              variant="outlined"
              shape="rounded"
              color="primary"
            />
          </Stack>
        </div>
      ) : (
        ""
      )}

      <DashboardImageModal
        IsOpen={IsOpen}
        setIsOpen={setIsOpen}
        Image={Image}
      />
    </>
  );
};

export default List;
