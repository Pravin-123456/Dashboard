import dashboard from '../../assets/powerbi.webp'

const SidebarR = () => {
  return (
    <article className="h-[100vh] bg-[#fff] py-5 px-10 border-l-1 border-[#cecece] pt-[2.5vw]">
      <h1 className="text-[1.5vw] text-center">
        MICROSOFT POWER BI <br /> PROJECTS
      </h1>
      <img
        src={dashboard}
        alt="Power BI"
        loading="eager"
        decoding="async"
        fetchPriority="high"
        // width="420"
        // height="300"
        className="w-[13vw] object-cover translate-x-[2vw]"
      />

      <footer className="text-[.9vw] text-justify leading-[1.6vw] mt-[1.5vw]">
        <span className={`text-[#983BFA] text-[1vw]`}>Nubinez</span> delivers world-class, end-to-end technology solutions by
        leveraging our deep industry knowledge and digital expertise. By
        bringing together technologies, industries, and the contributions of
        diverse individuals with their areas of expertise, we can solve problems
        better and faster.
      </footer>
    </article>
  );
};

export default SidebarR;
