import { NavLink, useNavigate } from "react-router-dom";
import { Folder, LogOut, LayoutDashboard, Users } from "lucide-react";
import { toast } from "react-toastify";
import { GetUsers } from "../../api/users";
import { useEffect, useState } from "react";
import Swal from "sweetalert2";

const Sidebar = () => {
  const [isAdmin, setIsAdmin] = useState(null);
  const userTypeId = sessionStorage.getItem("UserTypeID");
  const username = sessionStorage.getItem("UserName");
  const navigate = useNavigate();

  const handleLogout = () => {
    Swal.fire({
      title: "Are you sure?",
      text: "You will be logged out from the session.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#983BFA",
      cancelButtonColor: "",
      confirmButtonText: "Yes",
      cancelButtonText: "Cancel",
    }).then((result) => {
      if (result.isConfirmed) {
        sessionStorage.clear();
        setTimeout(() => {
          navigate("/");
        }, 500);
      }
    });
  };

  useEffect(() => {
    const check = async () => {
      try {
        const response = await GetUsers();
        const user = response.find((data) => data.user_name == username);
        if (!user) {
          sessionStorage.clear();
          toast.error("Invalid user session.");
          navigate("/");
        } else {
          setIsAdmin(user);
        }
      } catch (error) {
        console.error("User fetch error:", error);
        sessionStorage.clear();
        navigate("/");
      }
    };
    check();
  }, [username, navigate]);

  // console.log("admin", isAdmin?.user_name);

  const navlinks = [
    {
      title: "Users",
      link: "/main/users",
      icon: Users,
    },
    {
      title: "Projects",
      link: "/main/projects",
      icon: Folder,
    },
  ];

  return (
    <nav className="flex flex-col justify-between py-[4.5vh] text-center text-[1.1vw] h-[100vh] relative overflow-hidden border-r-1 border-[#cecece]">
      <div className="items-center justify-center gap-[1.3vw]">
        <h3 className="text-[1vw] font-normal">Welcome</h3>
        <h3 className="font-bold text-[1.2vw]">
          {isAdmin?.user_name || "..."}
        </h3>
      </div>
      <div className="">
        <ul className="flex flex-col text-start pl-[3vw] space-y-7">
          <NavLink
            to="/main"
            end
            className={({ isActive }) =>
              `flex items-center gap-[1vw] transition duration-300 hover:text-[#983BFA] hover:scale-105 text-[1vw] ${
                isActive ? "text-[#983BFA] scale-105" : "text-gray-800"
              }`
            }
          >
            <LayoutDashboard className="w-[1.5vw]" />
            Dashboard
          </NavLink>

          {/* Conditional Links for Admins */}
          {userTypeId === "1" &&
            navlinks.map((link, index) => (
              <NavLink
                key={index}
                to={link.link}
                className={({ isActive }) =>
                  `flex items-center gap-[1vw] transition duration-300 hover:text-[#983BFA] hover:scale-105 text-[1vw] ${
                    isActive ? "text-[#983BFA] scale-105" : "text-gray-800"
                  }`
                }
              >
                <link.icon className="w-[1.5vw]" />
                {link.title}
              </NavLink>
            ))}
        </ul>
      </div>
      <div className="">
        <div
          onClick={handleLogout}
          className={`flex justify-center items-center gap-[1vw] hover:text-[#983BFA] hover:scale-105 transition duration-300 -translate-x-5 cursor-pointer`}
        >
          <LogOut />
          <span>Logout</span>
        </div>
      </div>
    </nav>
  );
};

export default Sidebar;
