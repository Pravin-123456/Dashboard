import React, { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { UserLogin } from "../../api/login";
import { ErrorMessage, Field, Form, Formik } from "formik";
import * as Yup from "yup";
import { Eye, EyeOff } from "lucide-react";
import { toast } from "react-toastify";

const LoginForm = () => {
  const navigate = useNavigate();
  const [showPass, setShowPass] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const input1Ref = useRef(null);
  const input2Ref = useRef(null);

  const handleKeyDown = (e, nextRef) => {
    if (e.key === "Enter" && nextRef?.current) {
      e.preventDefault();
      nextRef.current.focus();
    }
  };

  const handleSubmit = async (values) => {
    try {
      const response = await UserLogin(values);
      if (response?.token) {
        navigate("/main");
        console.log("Submitted Values:", values);
      } else {
        console.log("Login failed");
      }
    } catch (error) {
      console.log("Error from login", error.message);
    }
  };

  
  
  return (
   <div className="">
      <Formik
        initialValues={{
          user_name: "",
          password: "",
        }}
        validationSchema={Yup.object({
          user_name: Yup.string().required("Enter Your Employee ID"),
          password: Yup.string().required("Enter Your Password"),
        })}
        onSubmit={(values, actions) => {
          handleSubmit(values);
          console.log("login form data's", values);
          actions.resetForm();
        }}
      >
        <Form>
          <div className="flex flex-col justify-around space-y-[1vw]">
            <div className="">
              <label htmlFor="user_name" className="text-[1.1vw]">
                Employee ID
              </label>
              <div>
                <Field
                  type="text"
                  id="user_name"
                  name="user_name"
                  ref={input1Ref}
                  placeholder="Enter your ID"
                  onKeyDown={(e) => handleKeyDown(e, input2Ref)}
                  className="border border-[#fff] h-[3vw] w-[25vw]  rounded-[.5vw] placeholder:text-[1vw] px-[.5vw] focus:outline-none bg-white"
                />
                <p className="h-[1vw]">
                  <ErrorMessage
                    name="user_name"
                    component="div"
                    className="text-red-600 text-[1vw]"
                  />
                </p>
              </div>
            </div>

            <div className="flex flex-col text-left">
              <label
                htmlFor="password"
                className="mb-1 text-[1.1vw] font-normal"
              >
                Password
              </label>

              <div>
                <div
                  className={`flex items-center h-[3vw] w-[25vw] rounded-[.5vw] bg-white 
        ${isFocused ? "border-2 border-[#983BFA]" : "border border-[#d8c4c4]"}`}
                >
                  <Field
                    type={showPass ? "text" : "password"}
                    id="password"
                    name="password"
                    placeholder="Enter your password"
                    autoComplete="off"
                    innerRef={input2Ref}
                    className="w-[90%] px-[1vw] placeholder:text-[1vw] h-[3vw] !text-[1vw] outline-none"
                    // onFocus={() => setIsFocused(true)}
                    // onBlur={() => setIsFocused(false)}
                  />

                  {showPass ? (
                    <Eye
                      className="text-[#c0b2b2] h-[1.5vw] cursor-pointer"
                      onClick={() => setShowPass(false)}
                    />
                  ) : (
                    <EyeOff
                      className="text-[#c0b2b2] h-[1.5vw] cursor-pointer"
                      onClick={() => setShowPass(true)}
                    />
                  )}
                </div>

                <p className="mt-1 h-[1vw]">
                  <ErrorMessage
                    name="password"
                    component="div"
                    className="text-red-600 text-[1vw]"
                  />
                </p>
              </div>
            </div>

            <div>
              <button
                type="submit"
                className=" h-[3.2vw] w-[25vw] rounded-[.5vw] text-[1.2vw] mt-[1vw] cursor-pointer bg-[#983BFA] text-white mb-[1.5vw]"
              >
                Log In
              </button>
            </div>
          </div>
        </Form>
      </Formik>
    </div>
  );
};

export default LoginForm;
