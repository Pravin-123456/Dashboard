import Login_img from "../../assets/login.svg";
import LoginForm from "./LoginForm";
import Logo from "../../assets/nubiznez.webp";

const LoginPage = () => {
  return (
    <div className="h-screen w-screen bg-white grid grid-cols-[50%_50%] overflow-hidden">
      <div className="">
        <img
          src={Login_img}
          alt="Login"
          className="!w-[50vw] h-[100vh] object-cover"
        />
      </div>
      <div className="relative">
        <div className="w-[80%] h-[80%] bg-[#D6B1FD] relative top-1/2 left-1/2 -translate-1/2 rounded-xl shadow-xl overflow-hidden">
          <div className="relative top-1/2 -translate-y-1/2 justify-self-center space-y-[1vw] grid h-[80%] w-full justify-center">
            <div className="flex justify-center gap-[.5vw] m-[1vw]">
              <img src={Logo} alt="Logo" className="w-[3vw] h-[3vw]" />
              <h1 className=" text-[2vw] font-semibold">REPORTING PORTAL</h1>
            </div>
            <div className="">
              <h1 className="text-[2vw] text-center">Sign in</h1>
            </div>
            <LoginForm />
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
