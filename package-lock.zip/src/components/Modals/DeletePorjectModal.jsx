import { Modal } from "antd";
import delete_icon from '../../assets/delete.png'

const DeleteProjectModal = ({
  isDeleteModalOpen,
  handleCancel,
  hideDeleteModal,
  title,
  project_id,
  handleConfirmDelete,
}) => {
    
  return (
    <Modal
      
      open={isDeleteModalOpen}
      onCancel={handleCancel}
      footer={null}
      centered
      width={"25vw"}
    >
      <div className="flex flex-col items-center"> 
        <img src={delete_icon} alt="delete icon" className="w-[12vw]"/>
        <p className=" text-gray-700 mt-[2vw] !text-[1vw] text-center">
          Are you sure you want to delete user<br/> <strong>{title}</strong>?
        </p>
        <div className="flex justify-center gap-5 mt-5">
           <button
            onClick={() => handleConfirmDelete(project_id,title)}
            className="bg-[#983BFA] text-white font-bold py-[.5vw] px-[1.2vw] rounded !text-[1vw] cursor-pointer"
          >
            Delete
          </button>
          <button
            onClick={hideDeleteModal}
            className="border-2 border-[#983BFA] text-gray-700 font-semibold py-[.5vw] px-[1vw] rounded !text-[1vw] cursor-pointer"
          >
            Cancel
          </button>
         </div>
      </div>
    </Modal>
  );
};

export default DeleteProjectModal;
