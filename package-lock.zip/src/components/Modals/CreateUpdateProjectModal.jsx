import { Formik } from "formik";
import * as Yup from "yup";
import { NewProject, UpdateProjectDetails } from "../../api/projects";
import { GetUsers } from "../../api/users";
import { toast } from "react-toastify";
import { useEffect, useRef, useState } from "react";
import { Select } from "antd";
import { X } from "lucide-react";
import Delete from "../../assets/delete.png";

const CreateProjectModal = ({
  isModalVisible,
  handleCancel,
  selectedProjects,
  handleOk,
  setPreview,
  Preview
}) => {
  const [Projects, setProjects] = useState([]);
  const fileInputRef = useRef(null);
  const path = "http://192.168.90.43:5001"

  const validationSchema = Yup.object({
    title: Yup.string()
      .max(50, "Title must be 50 characters or less")
      .required("Enter Project Title"),
    image: Yup.mixed()
      .required("Upload Project Image")
      .test("fileSize", "File too large. Maximum size is 5MB.", (value) => {
        if (!value) return false;
        if (typeof value === "string") return true;
        return value.size <= 5 * 1024 * 1024;
      })
      .test(
        "fileType",
        "Unsupported file format. Only JPG, JPEG, PNG allowed.",
        (value) => {
          if (!value) return false;
          if (typeof value === "string") return true;
          return ["image/jpeg", "image/jpg", "image/png"].includes(value.type);
        }
      ),

    link: Yup.string().url("Enter a valid URL").required("Enter Project Link"),
    access_propertie: Yup.array()
      .min(1, "Select at least one user")
      .of(
        Yup.object().shape({
          id: Yup.number().required(),
          name: Yup.string().required(),
        })
      ),
  });

  let access_propertie = [];
  try {
    access_propertie = Array.isArray(selectedProjects?.access_propertie)
      ? selectedProjects.access_propertie
      : JSON.parse(selectedProjects?.access_propertie || "[]");
  } catch {
    access_propertie = [];
  }

  const initialValues = {
    title: selectedProjects?.title || "",
    image: selectedProjects?.image || null,
    link: selectedProjects?.link || "",
    access_propertie: access_propertie || [],
  };

  const fetchUser = async () => {
    const data = await GetUsers();
    setProjects(data);
  };

  useEffect(() => {
    fetchUser();
  }, []);

  const userOptions = Projects.map((user) => ({
    label: user.user_name,
    value: user.user_id,
  }));

  if (!isModalVisible) return null;

  const handleBackdropClick = (e) => {
    if (e.target.id === "modal-backdrop") {
      handleCancel();
    }
  };

  return (
    <div
      id="modal-backdrop"
      onClick={handleBackdropClick}
      className="fixed inset-0 bg-black/30 bg-opacity-30 flex items-center justify-center z-50"
    >
      <div className="relative bg-white w-[30vw] max-h-[90vh] overflow-y-auto rounded-xl p-6 shadow-lg">
        <button
          onClick={handleCancel}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-xl font-bold"
        >
          <X className="w-[1.2vw] cursor-pointer hover:text-[#983BFA]" />
        </button>

        <div className="text-left text-[1.2vw] font-semibold mb-4">
          {selectedProjects ? "Update Project" : "Create New Project"}
        </div>

        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={async (values) => {
            try {
              const projectPayload = {
                title: values.title,
                image: values.image,
                link: values.link,
                access_propertie: values.access_propertie,
                project_id: selectedProjects?.project_id ?? null,
              };

              const isChanged =
                selectedProjects &&
                (selectedProjects.title !== values.title ||
                  selectedProjects.link !== values.link ||
                  selectedProjects.image !== values.image ||
                  JSON.stringify(selectedProjects.access_propertie || []) !==
                    JSON.stringify(values.access_propertie));

              if (selectedProjects) {
                if (!isChanged) {
                  toast.info("No changes detected.");
                  return;
                }
                await UpdateProjectDetails(projectPayload);
                toast.success("Project updated successfully!");
                handleOk();
              } else {
                await NewProject(projectPayload);
                toast.success("Project created successfully!");
                handleOk();
              }
            } catch (error) {
              console.error("Error submitting form:", error);
              toast.error("Something went wrong. Please try again.");
            }
          }}
          enableReinitialize
        >
          {({
            handleSubmit,
            handleChange,
            handleBlur,
            setFieldValue,
            setFieldTouched,
            values,
            errors,
            touched,
          }) => (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="flex flex-col text-left lable">
                <label className="mb-1 font-normal text-[1vw]">
                  Project Title
                </label>
                <input
                  name="title"
                  placeholder="Enter Project Title"
                  value={values.title}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className="border border-gray-300 text-gray-600 placeholder-gray-400 rounded-md  px-[.6vw] py-[1vh] h-[2.5vw] w-full text-[1vw]"
                />
                <p className="text-red-500 text-[.8vw] h-[.5vw]">
                  {touched.title && errors.title && errors.title}
                </p>
              </div>

              <div className="flex flex-col text-left lable">
                <label className="mb-1 font-normal text-[1vw]">
                  Project Link
                </label>
                <input
                  name="link"
                  placeholder="Enter Project Link"
                  value={values.link}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className="border border-gray-300 text-gray-600 placeholder-gray-400 rounded-md  px-[.6vw] py-[1vh] h-[2.5vw] w-full text-[1vw]"
                />
                <p className="text-red-500 text-[.8vw] h-[.5vw]">
                  {touched.link && errors.link && errors.link}
                </p>
              </div>

              <div className="flex flex-col text-left lable">
                <label className="mb-1 font-normal text-[1vw]">
                  Project Image
                </label>
                <div className="border border-gray-300 text-gray-600 rounded-md  py-[1vh] h-[2.5vw] w-full flex justify-between items-center">
                  <input
                    ref={fileInputRef}
                    type="file"
                    name="image"
                    onBlur={() => setFieldTouched("image", true)}
                    onChange={(event) => {
                      const file = event.currentTarget.files[0];
                      if (file) {
                        setFieldValue("image", file);
                        setPreview(URL.createObjectURL(file));
                      }
                    }}
                    className="placeholder-gray-400 text-[1vw] px-[.6vw] border-none"
                  />
                  {values.image || Preview ?
                  <img
                    src={typeof values.image === "string" ? path + values.image : Preview}
                    alt={Preview}
                    className="w-[4vw] h-[2.5vw] rounded-r-md !border-none border-transparent"
                  /> : ''}
                </div>
                <p className="text-red-500 text-[.8vw] h-[.5vw]">
                  {touched.image && errors.image ? errors.image : ""}
                </p>
              </div>

              <div className="flex flex-col text-left lable">
                <label className="mb-1 font-normal text-[1vw]">Users</label>
                <Select
                  variant="borderless"
                  mode="multiple"
                  value={values.access_propertie.map((u) => u.id)}
                  onChange={(selectedIds) => {
                    const selectedUsers = selectedIds
                      .map((id) => {
                        const user = userOptions.find((u) => u.value === id);
                        return user
                          ? { id: user.value, name: user.label }
                          : null;
                      })
                      .filter(Boolean);
                    setFieldValue("access_propertie", selectedUsers);
                  }}
                  onBlur={() => setFieldTouched("access_propertie", true)}
                  placeholder="Select users"
                  className="border border-gray-300 text-gray-600 placeholder-gray-400 rounded-md !h-[2.5vw] text-[1vw]"
                  style={{
                    minHeight: "5.2rem",
                    maxHeight: "10rem",
                    overflowY: "auto",
                  }}
                  options={userOptions}
                />
                <p className="text-red-500 text-[.8vw] h-[.5vw]">
                  {touched.access_propertie &&
                    errors.access_propertie &&
                    errors.access_propertie}
                </p>
              </div>

              <div className="text-right mb-[1vw] ">
                <button
                  type="submit"
                  className="w-full bg-purple-600 text-white px-6 py-2 text-[1.2vw] rounded-md hover:bg-purple-700 cursor-pointer"
                >
                  {selectedProjects ? "Update" : "Create"}
                </button>
              </div>
            </form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default CreateProjectModal;
