import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";

const handleLogout = () => {
    const navigate = useNavigate()
  Swal.fire({
    title: "Are you sure?",
    text: "You will be logged out from the session.",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#3085d6",
    confirmButtonText: "Yes, logout",
    cancelButtonText: "Cancel",
  }).then((result) => {
    if (result.isConfirmed) {
      sessionStorage.clear();
      setTimeout(() => {
        navigate("/");
      }, 1000);
    }
  });
};

export default handleLogout;
