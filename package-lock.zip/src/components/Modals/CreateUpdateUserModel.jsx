import { Formik } from "formik";
import * as Yup from "yup";
import { NewProjectUser, UpdateProjetUser } from "../../api/users";
import { toast } from "react-toastify";
import Create_user_svg from "../../assets/User_Creation.svg";
import { X } from 'lucide-react';

const CreateUserModel = ({
  isModalVisible,
  handleCancel,
  handleOk,
  selectedUser,
  users,
}) => {
  const validationSchema = Yup.object({
    emp_no: Yup.number().required("Enter Employee Number"),
    user_name: Yup.string().max(30, "Name must be below 30 characters").required("Enter User Name"),
    pass: Yup.string().required("Enter Password"),
    user_type: Yup.string().required("Select User Type"),
  });

  const initialValues = {
    emp_no: selectedUser?.emp_no || "",
    user_name: selectedUser?.user_name || "",
    pass: selectedUser?.pass || "",
    user_type: selectedUser?.user_type || "",
  };

  if (!isModalVisible) return null;

  const handleBackdropClick = (e) => {
    if (e.target.id === "modal-backdrop") {
      handleCancel();
    }
  };

  return (
    <div
      id="modal-backdrop"
      onClick={handleBackdropClick}
      className="fixed inset-0 bg-black/30 bg-opacity-30 flex items-center justify-center z-50 "
    >
      <div className="relative bg-white w-[30vw] max-h-[80vh] overflow-hidden rounded-xl p-6 shadow-lg">
        <button
          onClick={handleCancel}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-xl font-bold"
        >
          <X className="w-[1.2vw] cursor-pointer hover:text-[#983BFA]"/>
        </button>

        <div className="text-left text-[1.2vw] font-semibold mb-4">
          {selectedUser ? "Update User" : "Create New User"}
        </div>

        <div className="">
          <div>
            <Formik
              key={selectedUser?.user_id || "create"}
              initialValues={initialValues}
              validationSchema={validationSchema}
              onSubmit={async (values, { setSubmitting }) => {
                try {
                  if (!selectedUser) {
                    const isUserExist = users.some(
                      (user) => user.emp_no === Number(values.emp_no)
                    );

                    if (isUserExist) {
                      toast.error("User already exists with this Employee ID");
                      return;
                    }
                  }

                  const user_type_id = values.user_type === "admin" ? 1 : 0;

                  const userPayload = {
                    emp_no: Number(values.emp_no),
                    user_name: values.user_name,
                    password: values.pass,
                    user_id: selectedUser?.user_id ?? null,
                    user_type: values.user_type,
                    user_type_id: user_type_id,
                    department_id: 0,
                    department_name: "",
                  };

                  if (selectedUser) {
                    const isChanged =
                      selectedUser.emp_no !== Number(values.emp_no) ||
                      selectedUser.user_name !== values.user_name ||
                      selectedUser.pass !== values.pass ||
                      selectedUser.user_type !== values.user_type;

                    if (!isChanged) {
                      toast.info("No changes detected.");
                      return;
                    }

                    await UpdateProjetUser(userPayload);
                    toast.success("User updated successfully!");
                  } else {
                    await NewProjectUser(userPayload);
                    toast.success("User created successfully!");
                  }

                  handleOk();
                } catch (error) {
                  console.error("Error submitting form:", error);
                  toast.error("Something went wrong. Please try again.");
                }
              }}
              enableReinitialize
            >
              {({ handleSubmit, handleChange, handleBlur, setFieldValue, values, errors, touched, isSubmitting }) => (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="flex flex-col text-left lable">
                    <label className="mb-1 font-normal text-[1vw]">Employee ID</label>
                    <input
                      name="emp_no"
                      type="text"
                      value={values.emp_no}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      placeholder="Enter Employee ID"
                      className="border border-gray-300 text-gray-600 placeholder-gray-400 rounded-md px-[.6vw] py-[1vh] h-[2.5vw]  w-full"
                    />
                    <p className="text-red-500 text-[.8vw] h-[.5vw]">{touched.emp_no && errors.emp_no && errors.emp_no}</p>
                  </div>

                  <div className="flex flex-col text-left lable">
                    <label className="mb-1 font-normal text-[1vw]">Employee Name</label>
                    <input
                      name="user_name"
                      value={values.user_name}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      placeholder="Enter Employee Name"
                      className="border border-gray-300 text-gray-600 placeholder-gray-400 rounded-md px-[.6vw] py-[1vh] h-[2.5vw] w-full"
                    />
                    <p className="text-red-500 text-[.8vw] h-[.5vw]">{touched.user_name && errors.user_name && errors.user_name}</p>
                  </div>

                  <div className="flex flex-col text-left lable">
                    <label className="mb-1 font-normal text-[1vw]">Password</label>
                    <input
                      name="pass"
                      type="password"
                      value={values.pass}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      placeholder="Enter Password"
                      className="border border-gray-300 text-gray-600 placeholder-gray-400 rounded-md px-[.6vw] py-[.5vw] h-[2.5vw] w-full"
                    />
                    <p className="text-red-500 text-[.8vw] h-[.5vw]">{touched.pass && errors.pass && errors.pass}</p>
                  </div>

                  <div className="flex flex-col text-left lable">
                    <label className="mb-1 font-normal text-[1vw] ">User Type</label>
                    <select
                      name="user_type"
                      value={values.user_type}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      className="border border-gray-300 text-gray-600 placeholder-gray-400 rounded-md px-[.6vw] py-[1vh] w-full h-[2.5vw] user_type"
                    >
                      <option value="" disabled>Select User Type</option>
                      <option value="admin">Admin</option>
                      <option value="user">User</option>
                    </select>
                    <p className="text-red-500 text-[.8vw] h-[.5vw]">{touched.user_type && errors.user_type && errors.user_type}</p>
                  </div>

                  <div className="text-right lable">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-purple-600 text-white px-[.6vw] py-[1vh] rounded-md hover:bg-purple-700 text-[1.2vw] cursor-pointer"
                    >
                      {selectedUser ? "Update" : "Create"}
                    </button>
                  </div>
                </form>
              )}
            </Formik>
          </div>
          {/* <div>
            <img
              src={Create_user_svg}
              alt="Create user"
              className="w-full h-full object-contain"
            />
          </div> */}
        </div>
      </div>
    </div>
  );
};

export default CreateUserModel;
