import { Modal } from "antd";

const DashboardImageModal = ({ IsOpen, setIsOpen, Image }) => {
  return (
    <Modal
      centered
      open={IsOpen}
      onCancel={() => setIsOpen(false)}
      footer={null}
      closable={false}
      width="auto"
      style={{
        padding: 0,
        maxHeight: "80vh",
        color: "white"
      }}
    >
      <img
        src={Image}
        alt="Project Preview"
        style={{
          maxWidth: "20vw",
          maxHeight: "70vh",
          objectFit: "contain",
          borderRadius: "8px",
        }}
      />
    </Modal>
  );
};

export default DashboardImageModal;
