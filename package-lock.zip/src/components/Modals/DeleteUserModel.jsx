import { Modal } from "antd";
import delete_icon from "../../assets/delete.png";

const DeleteUserModel = ({
  isDeleteModalOpen,
  handleCancel,
  hideDeleteModal,
  user_id,
  user_name,
  handleConfirmDelete,
}) => {
  return (
    <Modal
      open={isDeleteModalOpen}
      onCancel={handleCancel}
      footer={null}
      centered
      width={"25vw"}
    >
      <div className="flex flex-col items-center">
        <img src={delete_icon} alt="delete icon" className="w-[12vw]" />
        <p className="text-center text-gray-700 mt-[2vw] !text-[1vw]">
          Are you sure you want to delete user <br />{" "}
          <strong>{user_name}</strong>?
        </p>
        <div className="flex justify-center gap-5 mt-5">
          <button
            onClick={() => handleConfirmDelete(user_id, user_name)}
            className="bg-[#983BFA] text-white font-bold py-[.5vw] px-[1.2vw] rounded !text-[1vw] cursor-pointer"
          >
            Delete
          </button>
          <button
            onClick={hideDeleteModal}
            className="border-[#983BFA] border-2 text-gray-700 font-semibold py-[.5vw] px-[1vw] rounded !text-[1vw] cursor-pointer"
          >
            Cancel
          </button>
          
        </div>
      </div>
    </Modal>
  );
};

export default DeleteUserModel;
