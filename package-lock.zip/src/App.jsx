import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import MainLayout from "./components/main/MainPage";
import "react-toastify/dist/ReactToastify.css";
import { lazy } from "react";
import LoginPage from "./components/login/LoginPage";

const DashBoard = lazy(() => import("./components/dashboard/DashBoard"));
const Users = lazy(() => import("./components/users/Users"));
const Projects = lazy(() => import("./components/projects/Projects"));

const App = () => {
  return (
    <>
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover
        draggable
      />
      <Router>
        <Routes>
          <Route index element={<LoginPage />} />
          <Route path="/main" element={<MainLayout />}>
            <Route index element={<DashBoard />} />
            <Route path="users" element={<Users />} />
            <Route path="projects" element={<Projects />} />
          </Route>
        </Routes>
      </Router>
    </>
  );
};

export default App;
