import React, { useState } from 'react';
import { UserLogin } from './api/login';

const Just_try = () => {
  const [formValues, setFormValues] = useState({
    user_name: '',
    password: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await UserLogin(formValues)
      console.log("Submitted Values:", formValues);
    } catch (error) {
      console.log("Error from login",error.message);
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="name">Employee ID</label>
          <input
            type="text"
            name="user_name"
            placeholder='Enter your ID'
            className="border-2 border-[#d3cece]  p-2"
            onChange={handleChange}
            value={formValues.name}
          />
        </div>
        <div className="mb-4">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            name="password"
            className="border-2 border-[#d3cece] p-2"
            placeholder='Enter your password'
            onChange={handleChange}
            value={formValues.password}
          />
        </div>
        <div>
          <button type="submit" className="border-2 border-[#d3cece] px-4 py-2">
            Log In
          </button>
        </div>
      </form>
    </div>
  );
};

export default Just_try;


// const fetchProjects = async (search) => {
  //   try {
  //     setLoading(true);

  //     const response = search
  //       ? await SearchProjects(search)
  //       : await GetProjectDetails();

  //     console.log("Projects from dashboard", search);
  //     setProjects(response || []);
  //   } catch (error) {
  //     console.log("Fetch Projects Error", error.message);
  //   } finally {
  //     setLoading(false);
  //   }
  // };