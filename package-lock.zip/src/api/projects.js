import axios from "axios";
import { toast } from "react-toastify";

const url = import.meta.env.VITE_CASH_FLOW_URL;

export const NewProject = async (values) => {
  console.log(values.image, "imagessss");
  const projectPayload = new FormData();

  projectPayload.append("title", values.title);
  projectPayload.append("image", values.image);
  projectPayload.append("link", values.link);
  const accessList = JSON.stringify(values.access_propertie);
  projectPayload.append("access_propertie", accessList);

  console.log("this from api", projectPayload);

  try {
    const response = await axios.post(`${url}/project-details`, projectPayload);
    console.log(projectPayload, "payload");
    return response.data;
  } catch (err) {
    console.log(err, "this is error");
    toast.error(err.response.data.message);
  }
};

const AdminProjects = async () => {
  try {
    const response = await axios.get(`${url}/project-details`);
    return response.data;
  } catch (error) {
    console.log("project fetcing error", error.message);
    return;
  }
};

const UserProjects = async () => {
  const userID = sessionStorage.getItem("userId");
  try {
    const response = await axios.get(`${url}/role/based/projects/${userID}`);
    return response.data;
  } catch (error) {
    console.log("project fetcing error", error.message);
    return;
  }
};

export const GetProjectDetails = async () => {
  const userType = sessionStorage.getItem("UserTypeID");

  try {
    const response =
      userType === "1" ? await AdminProjects() : await UserProjects();

    console.log(response, "get");
    return response;
  } catch (err) {
    console.error("GetProjectDetails error:", err);
  }
};

export const UpdateProjectDetails = async (values) => {
  const projectPayload = new FormData();

  projectPayload.append("title", values.title);
  projectPayload.append("image", values.image);
  projectPayload.append("link", values.link);
  projectPayload.append("id", values.project_id);
  projectPayload.append(
    "access_propertie",
    JSON.stringify(values.access_propertie)
  );

  console.log("payload", projectPayload);
  try {
    const response = await axios.put(
      `${url}/project-details/${values.project_id}`,
      projectPayload
    );
    console.log(response, "updated project details");
    console.log(projectPayload, "UPD payload");
    return response.data;
  } catch (err) {
    console.log(err, "this is error");
  }
};

export const DeleteProjectDetails = async (id) => {
  try {
    const response = await axios.delete(`${url}/project-details/${id}`);
    return response.data;
  } catch (err) {
    console.log(err, "this is deletion error");
  }
};

export const GetProgectDetailsById = async (id) => {
  try {
    const response = await axios.get(`${url}/project-details/${id}`);
    console.log(response, "GetProgectDetailsById");
    return response.data;
  } catch (err) {
    console.log(err, "this is deletion error");
  }
};
