import axios from "axios";
import { toast } from "react-toastify";

const url = import.meta.env.VITE_CASH_FLOW_URL;
export const UserLogin = async (values) => {
  const loginPayload = {
    user_name: values?.user_name,
    password: values?.password,
  };
  try {
    const response = await axios.post(`${url}/user-login`, loginPayload);
    console.log("Login response:", response.data);
    if (response?.data?.error) {
      toast.warning(response.data.error);
    }
    sessionStorage.setItem("userId", response.data.userId);
    sessionStorage.setItem("Token", response.data.token);
    sessionStorage.setItem("UserName", response.data.user_name);
    sessionStorage.setItem("UserTypeID", response.data.userTypeId);
    return response.data;
  } catch (err) {
    toast.error(err.message);
    console.log(err, "this is error");
  }
};
