import axios from "axios";
import { toast } from "react-toastify";

const url = import.meta.env.VITE_CASH_FLOW_URL;
export const GetUsers = async () => {
  try {
    const response = await axios.get(`${url}/getProjectUser`);
    console.log("GETUSER", response.data.message);

    return response.data.message;
  } catch (err) {
    console.log(err, "Failed to Get Users");
  }
};

export const NewProjectUser = async (userPayload) => {
  try {
    const response = await axios.post(`${url}/newProjetUser`, userPayload, {
      headers: { "Content-Type": "application/json" },
    });
    console.log("User created:", response.data);
    return response.data;
  } catch (err) {
    console.error("Error setting up request:", err.message);
    throw err;
  }
};

export const UpdateProjetUser = async (userPayload) => {
  try {
    const response = await axios.put(
      `${url}/updateProjetUser/${userPayload.user_id}`,
      userPayload,
      { headers: { "Content-Type": "application/json" } }
    );
    console.log("Updated successfully", userPayload, response.data);
    return response.data;
  } catch (err) {
    console.error("Error setting up request:", err.message);
    throw err;
  }
};

export const DeleteProjetUser = async (id) => {
  try {
    const response = await axios.delete(`${url}/deleteProjetUser/${id}`);
    return response.data;
  } catch (error) {
    console.error("Error deleting user:", error.message);
    throw error;
  }
};
