import axios from "axios";

const url = import.meta.env.VITE_CASH_FLOW_URL;

export const SearchProjects = async (search) => {
  try {
    const response = await axios.get(`${url}/search/project/details/${search}`);
    console.log("this is from search.js", response.data);
    return response.data;
  } catch (error) {
    console.error("Error in SearchProjects:", error);
    return null;
  }
};

export const SearchUser = async (search) => {
  try {
    const response = await axios.get(`${url}/search/user/details/${search}`);
    console.log("this is from search.js", response.data);
    return response.data;
  } catch (error) {
    console.error("Error in SearchProjects:", error);
    return null;
  }
};
